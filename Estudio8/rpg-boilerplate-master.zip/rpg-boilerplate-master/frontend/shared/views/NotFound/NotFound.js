'use strict'
import React from 'react'
import createReactClass from 'create-react-class'

const NotFound = createReactClass({
  render () {
    return (<div className='page-title'>Page Not Found</div>)
  }
})

export default NotFound
