-- Verify rpg:function_currentProfile on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
