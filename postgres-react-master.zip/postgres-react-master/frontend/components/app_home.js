import React, { Component } from 'react';

export default class AppHome extends Component {
	render() {
		return (
			<p>
				The app home component has been rendered here!
			</p>
		)
	}
}
