-- Verify rpg:table_profile_triggers on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
