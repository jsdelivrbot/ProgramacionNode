-- Verify rpg:table_credentials_rbac on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
