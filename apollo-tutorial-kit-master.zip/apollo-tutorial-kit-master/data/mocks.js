const mocks = {
  String: () => 'It works!'
};

export default mocks;
