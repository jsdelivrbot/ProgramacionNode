-- Verify rpg:function_logout on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
