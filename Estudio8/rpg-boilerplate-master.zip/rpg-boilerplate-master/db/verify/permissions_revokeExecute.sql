-- Verify rpg:permissions_revokeExecute on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
