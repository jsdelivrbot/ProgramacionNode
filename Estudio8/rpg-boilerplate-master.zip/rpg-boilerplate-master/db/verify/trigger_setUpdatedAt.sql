-- Verify rpg:trigger_setUpdatedAt on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
