-- Verify rpg:function_signup on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
