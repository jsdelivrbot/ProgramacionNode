import React from 'react'

const style = {
  padding: '16px'
}

export default () => (
  <div style={style}>
    <h1>Sorry!</h1>
    <p>Something went horribly wrong…</p>
  </div>
)
