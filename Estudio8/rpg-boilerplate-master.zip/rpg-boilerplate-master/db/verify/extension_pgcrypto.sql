-- Verify rpg:extension_pgcrypto on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
