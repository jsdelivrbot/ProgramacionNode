// 'use strict// @flow weak
//
// import React, { Component } from 'react';
// import PropTypes from 'prop-types';
// import Button from 'material-ui/Button';
// import Snackbar from 'material-ui/Snackbar';
// import IconButton from 'material-ui/IconButton';
// import CloseIcon from 'material-ui-icons/Close';
//
// const LoginFailedSnackbar = createReactClass({
//   getInitialState () {
//     return {
//       open: false,
//       message: null,
//     }
//   },
//   handleClick () {
//     this.setState({ open: true });
//   },
//   handleRequestClose(event, reason) => {
//     if (reason === 'clickaway') {
//       return;
//     }
//
//     this.setState({ open: false });
//   };
//
//   render() {
//     const { classes } = this.props;
//     return (
//       <div>
//         <Button onClick={this.handleClick}>Open simple snackbar</Button>
//         <Snackbar
//           anchorOrigin={{
//             vertical: 'bottom',
//             horizontal: 'left',
//           }}
//           open={this.state.open}
//           autoHideDuration={6e3}
//           onRequestClose={this.handleRequestClose}
//           SnackbarContentProps={{
//             'aria-describedby': 'message-id',
//           }}
//           message={<span id="message-id">Note archived</span>}
//           action={[
//             <Button key="undo" color="accent" dense onClick={this.handleRequestClose}>
//               UNDO
//             </Button>,
//             <IconButton
//               key="close"
//               aria-label="Close"
//               color="inherit"
//               className={classes.close}
//               onClick={this.handleRequestClose}
//             >
//               <CloseIcon />
//             </IconButton>,
//           ]}
//         />
//       </div>
//     );
//   }
// }
//
// SimpleSnackbar.propTypes = {
//   classes: PropTypes.object.isRequired,
// };
//
// export default withStyles(styleSheet)(SimpleSnackbar);
//
// OPEN SIMPLE SNACKBAR
// '
