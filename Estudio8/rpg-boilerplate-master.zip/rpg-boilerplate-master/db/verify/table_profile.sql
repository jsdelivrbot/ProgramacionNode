-- Verify rpg:table_profile on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
