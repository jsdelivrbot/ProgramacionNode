-- Verify rpg:table_profile_rls on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
