-- Verify rpg:schema_account on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
