-- Verify rpg:function_authenticate on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
