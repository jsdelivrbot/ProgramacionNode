-- Verify rpg:table_credentials on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
