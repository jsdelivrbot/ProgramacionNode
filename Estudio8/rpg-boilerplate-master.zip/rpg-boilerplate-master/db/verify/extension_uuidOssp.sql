-- Verify rpg:extension_uuidOssp on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
