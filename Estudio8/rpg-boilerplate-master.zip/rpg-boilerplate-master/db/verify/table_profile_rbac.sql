-- Verify rpg:table_profile_rbac on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
