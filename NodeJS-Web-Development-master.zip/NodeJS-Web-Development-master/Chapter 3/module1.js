var A = "value A";
var B = "value B";
exports.values = function() {
   return { A: A, B: B };
}
