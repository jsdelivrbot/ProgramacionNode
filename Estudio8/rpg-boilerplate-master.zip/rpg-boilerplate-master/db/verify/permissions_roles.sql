-- Verify rpg:permissions_roles on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
