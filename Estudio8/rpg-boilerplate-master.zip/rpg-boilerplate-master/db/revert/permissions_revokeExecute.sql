-- Revert rpg:permissions_revokeExecute from pg

BEGIN;

-- XXX Add DDLs here.

COMMIT;
