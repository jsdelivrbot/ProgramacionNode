-- Verify rpg:type_jwt on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
