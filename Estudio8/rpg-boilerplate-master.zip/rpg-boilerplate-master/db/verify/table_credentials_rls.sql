-- Verify rpg:table_credentials_rls on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
