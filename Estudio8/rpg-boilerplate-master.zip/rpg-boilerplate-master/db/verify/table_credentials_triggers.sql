-- Verify rpg:table_credentials_triggers on pg

BEGIN;

-- XXX Add verifications here.

ROLLBACK;
